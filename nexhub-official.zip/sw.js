const CACHE_NAME = 'nexhub-official-v1';

// Daftar seluruh aset & halaman HTML NEXHUB Official untuk di-cache
const ASSETS_TO_CACHE = [
  './',
  './index.html',
  './admin.html',
  './kontak.html',
  './privasi.html',
  './profile.html',
  './tentang.html',
  './topup.html',
  './css/style.css',
  './js/app-purchase.js',
  './js/auth.js',
  './js/main.js',
  './js/topup.js',
  './icon-192.png',
  './icon-512.png',
  './manifest.json'
];

// Install Service Worker & Simpan Cache
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('[Service Worker] Caching all NEXHUB assets');
      return cache.addAll(ASSETS_TO_CACHE);
    })
  );
  self.skipWaiting();
});

// Aktivasi & Bersihkan Cache Lama
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cache) => {
          if (cache !== CACHE_NAME) {
            console.log('[Service Worker] Deleting old cache:', cache);
            return caches.delete(cache);
          }
        })
      );
    })
  );
  self.clients.claim();
});

// Fetching Assets (Network First dengan Offline Fallback)
self.addEventListener('fetch', (event) => {
  event.respondWith(
    fetch(event.request)
      .catch(() => {
        return caches.match(event.request);
      })
  );
});
